# Git 管理策略分析

## 📊 目录结构分析

### 大文件/临时目录（不应纳入版本控制）
- **sessions/** - 72MB
  - 包含大量 JSONL session 记录
  - 单个文件最大 5.3MB
  - 动态生成，每次对话都会新增
  - 不影响代码功能

### 中等临时文件（不应纳入版本控制）
- **cache/** - 72KB
- **.ace-tool/** - 36KB
- **.ralph-state/** - 12KB
- **pi-session-*.html** - 284KB
- **pi-crash.log** - 10KB
- **pi-debug.log** - 11KB

### 敏感文件（绝对不应纳入版本控制）
- **auth.json** - 包含认证信息

## ✅ 应纳入版本控制的重要文件

### 核心代码
- **skills/** - 技能定义和文档
- **agents/** - 代理配置
- **commands/** - 命令定义
- **extensions/** - 扩展功能
- **plugin/** - 插件代码（仅源码，不含运行时数据）

### 文档
- **docs/** - 完整文档目录
- **README.md** - 项目说明
- **SYSTEM.md** - 系统文档
- **VERSIONS.md** - 版本历史
- **subagent.md** - 子代理文档

### 配置文件
- **models.json** - 模型配置
- **settings.json** - 系统设置
- **subagent-config.md** - 子代理配置
- **switch-system.sh** - 系统切换脚本
- **verify-subagent.sh** - 验证脚本

## 🎯 .gitignore 配置策略

### 1. Session 记录
```
sessions/
pi-session-*.html
```
**原因**：sessions 目录包含 72MB 的对话记录，每次对话都会新增文件，这些文件不影响代码功能，且会急剧增加仓库大小。

### 2. 缓存目录
```
cache/
.ace-tool/
.ralph-state/
```
**原因**：这些是运行时缓存，不应纳入版本控制。

### 3. 日志文件
```
*.log
pi-crash.log
pi-debug.log
```
**原因**：日志文件会不断增长，且包含运行时信息，不应纳入版本控制。

### 4. 系统文件
```
.DS_Store
```
**原因**：macOS 系统文件，不应纳入版本控制。

### 5. 敏感信息
```
auth.json
*.key
*.pem
```
**原因**：包含认证信息，绝对不能提交到公开仓库。

## 📋 Git 初始化建议

### 初始化仓库
```bash
cd ~/.pi/agent
git init
```

### 检查状态
```bash
git status
```

### 首次提交
```bash
git add .
git commit -m "Initial commit: Pi Agent core configuration and skills"
```

### 推送到远程（可选）
```bash
git remote add origin <your-repo-url>
git branch -M main
git push -u origin main
```

## 🔍 验证 .gitignore 生效

### 检查被忽略的文件
```bash
git check-ignore -v sessions/
git check-ignore -v pi-session-*.html
git check-ignore -v auth.json
```

### 强制添加被忽略的文件（如果需要）
```bash
git add -f <file>
```

## 📈 仓库大小优化

### 清理历史中的大文件（如果已经提交）
```bash
# 使用 BFG Repo-Cleaner 或 git filter-repo
# 示例：移除 sessions 目录
git filter-repo --path sessions --invert-paths
```

### 检查仓库大小
```bash
du -sh .git
```

## 🔄 日常工作流

### 添加新技能或配置
```bash
git add skills/your-new-skill/
git commit -m "Add new skill: [skill-name]"
```

### 更新文档
```bash
git add docs/
git commit -m "Update documentation"
```

### 检查更改
```bash
git status
git diff
```

## ⚠️ 注意事项

1. **不要提交 auth.json** - 包含敏感认证信息
2. **不要提交 sessions/** - 会急剧增加仓库大小
3. **定期清理本地 sessions** - 可以使用 cron job 定期清理
4. **使用 .gitignore** - 防止意外提交临时文件
5. **提交前检查** - 使用 `git status` 确认要提交的文件

## 📝 清理脚本示例

创建 `cleanup.sh` 定期清理临时文件：
```bash
#!/bin/bash
# 清理超过 7 天的 session 文件
find sessions/ -type f -name "*.jsonl" -mtime +7 -delete

# 清理超过 7 天的日志文件
find . -name "*.log" -mtime +7 -delete

# 清理 HTML session 文件
find . -name "pi-session-*.html" -mtime +7 -delete

echo "Cleanup completed"
```

## 🎓 最佳实践

1. **小而频繁的提交** - 每次添加一个技能或配置就提交
2. **清晰的提交信息** - 描述做了什么改变
3. **使用分支** - 开发新功能时使用分支
4. **定期推送** - 避免本地积累太多更改
5. **审查更改** - 提交前检查 `git diff`