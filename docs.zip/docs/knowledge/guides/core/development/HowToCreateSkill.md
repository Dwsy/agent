# HowToCreateSkill

## Goal (目标)
这份指南旨在解决什么问题？

## Prerequisites (前置知识)
- [[RelatedConcept]]

## Steps (步骤)

### 1. [Step Name]
详细说明...

### 2. [Step Name]
详细说明...

## Best Practices (最佳实践)
- ✅ Do: ...
- ❌ Don't: ...

## Examples (示例)
```typescript
// Good example
```
